require 'card'

class Hand
  attr_accessor :cards
  
  HANDS = [
    "nothing", "pair", "two pair", "set", "straight", "flush", "full house", "straight flush"
    ]
  
  def initialize(cards)
    @cards = cards
  end
  
  def hand
    if pair?
      return HANDS[1]
    else
      return HANDS[0]
    end
  end
  
  private
  def buckets
    (2..14).to_a.map do |x| 
      @cards.select do |c| 
        c.rank == x 
      end
    end
  end
  
  def pair?
    not buckets.map(&:count).select {|x| x > 1}.empty?
  end
  
  def two_pair?
    not buckets.map(&:count).select {|x| x > 1}.count > 1
  end
  
  def set?
    not buckets.map(&:count).select {|x| x > 2}.empty?
  end
  
  def four_of_a_kind?
    not buckets.map(&:count).select {|x| x > 3}.empty?
  end
  
  def straight?
    buckets.map(&:count).join('').include?('11111') or (buckets.map(&:count).join('').start_with?('1111') and buckets.map(&:count)[-1] == 1)
  end
  
  def flush?
    c = @cards[0]
    @cards.each do |other|
      if c.suit != other.suit
        return false
      end
    end
    true
  end
  
  def full_house?
    pair? and two_pair? and set?
  end
  
  def straight_flush?
    straight? and flush?
  end
end